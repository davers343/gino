﻿using DiscaricaWPF;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Media;

namespace impianto
{
    public partial class MainWindow : Window
    {
        private int counter = 0;
        private const double EspansioneTempo = 1.0;
        private const int DurataAnimazione = 2000; // in ms

        private readonly Deposito discarica;
        private readonly Deposito impiantoSelezione;
        private readonly Deposito impiantoCompostaggio;

        private readonly Queue<Camion> codaCamion = new Queue<Camion>();
        private readonly object codaCamionLock = new object();

        private const double PartenzaXCamion = 100.0;

        private readonly DispatcherTimer timer;
        private readonly DispatcherTimer timerGeneraCamion;
       

        public MainWindow()
        {
            InitializeComponent();
            counterTextBlock.Text = "Camion Totali: 0";
            discarica = new Deposito("Discarica", 1000 * EspansioneTempo, 0, 500 * EspansioneTempo, 0);
            impiantoSelezione = new Deposito("Impianto di selezionamento", 1000 * EspansioneTempo, 0, 500 * EspansioneTempo, 0);
            impiantoCompostaggio = new Deposito("Impianto di compostaggio", 1000 * EspansioneTempo, 0, 500 * EspansioneTempo, 0);

            timerGeneraCamion = new DispatcherTimer();
            timerGeneraCamion.Interval = TimeSpan.FromSeconds(5); // Intervallo di 5 secondi tra ogni camion nuovo
            timerGeneraCamion.Tick += TimerGeneraCamion_Tick;
            //timerGeneraCamion.Start();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(0.1);
            timer.Tick += Timer_Tick;
            timer.Start();

            GestioneCodaTask();
            ElaborazioneCamionTask();
        }
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            // Avvia i timer
            timerGeneraCamion.Start();
            timer.Start();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            // Arresta i timer
            timerGeneraCamion.Stop();
            timer.Stop();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            AggiornaLabelDeposito(discarica, discaricaLabelM, discaricaLabelV);
            AggiornaLabelDeposito(impiantoSelezione, impLabelM, impLabelV);
            AggiornaLabelDeposito(impiantoCompostaggio, compLabelM, compLabelV);
        }

        private void TimerGeneraCamion_Tick(object sender, EventArgs e)
        {
            // Genera automaticamente un camion quando scatta il timer
            Camion nuovoCamion = GeneraCamionRandom();
            counter++;
            counterTextBlock.Text = "Camion Totali: " + counter;

            lock (codaCamionLock)
            {
                // Verifica lo stato dei depositi prima di aggiungere il camion alla coda
                // Se il deposito è pieno, non aggiungere camion corrispondenti al suo materiale
                if (impiantoSelezione.isDepositoFull == true)
                {
                    Application.Current.Dispatcher.Invoke(() => camionInfoText.Text = string.Format("Camion {0} (diretto all'impianto) rifiutato", counter - 1));

                }else if (impiantoSelezione.isDepositoFull==false && (nuovoCamion.materialeTrasportato == "vetro" || nuovoCamion.materialeTrasportato == "plastica" || nuovoCamion.materialeTrasportato == "metallo" || nuovoCamion.materialeTrasportato == "organico"))
                {
                    // Aggiungi il camion alla coda
                   
                    // Avvia l'animazione del camion

                    codaCamion.Enqueue(nuovoCamion);



                }

                if (impiantoCompostaggio.isDepositoFull == true)
                {
                    Application.Current.Dispatcher.Invoke(() => camionInfoText.Text = string.Format("Camion {0} (diretto al compostaggio) rifiutato", counter - 1));

                }else if (impiantoCompostaggio.isDepositoFull == false && nuovoCamion.materialeTrasportato == "organico non triturato")
                {
                    codaCamion.Enqueue(nuovoCamion);
                   
                }
                

                if (discarica.isDepositoFull == true)
                {
                    Application.Current.Dispatcher.Invoke(() => camionInfoText.Text = string.Format("Camion {0} (diretto in discarica) rifiutato", counter - 1));
                }
                else if (discarica.isDepositoFull == false && nuovoCamion.materialeTrasportato == "preselezionato")
                {
                    codaCamion.Enqueue(nuovoCamion);
                    Thread.Sleep(4000);
                   
                }

            }
        }
        //camion prima su e poi nei box
        private async Task GestioneCodaTask()
        {
            Random random = new Random();
            while (true)
            {
                // Controlla se il timer è in pausa
                while (!timerGeneraCamion.IsEnabled)
                {
                    await Task.Delay(1000);
                }

                lock (codaCamionLock)
                {
                    if (codaCamion.Count > 0)
                    {
                        Camion nuovoCamion;
                        lock (codaCamionLock)
                        {
                            nuovoCamion = codaCamion.Dequeue();
                        }

                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            camionInfoText.Text = string.Format("In arrivo camion trasportante: {0} - Volume: {1} - Massa: {2}", nuovoCamion.materialeTrasportato, nuovoCamion.volume, nuovoCamion.massa);
                        });

                        ElaboraCamion(nuovoCamion, discarica, impiantoSelezione, impiantoCompostaggio);
                    }
                }
                await Task.Delay(500);
            }
        }
        private void ElaboraCamionIndifferenziata(Camion camion, Deposito impianto)
        {
            //discaricaN.Visibility = Visibility.Hidden;
            if (impiantoSelezione.AggiungiMateriale(camion.volume, camion.massa))
            {
                Application.Current.Dispatcher.Invoke(() => impiantoS.Text = string.Format("Camion {0} elaborato all'impianto di selezione", counter - 1));//per ora solo materiale organico;
               
                Thread.Sleep(4000);

                if (camion.materialeTrasportato == "plastica" || camion.materialeTrasportato == "metallo" || camion.materialeTrasportato == "vetro")
                {
                    Application.Current.Dispatcher.Invoke(() => impiantoS.Text = string.Format("Camion {0} con  ( {1} ) in transito\n-In attesa di essere prelevato-", counter - 1, camion.materialeTrasportato));
                    Random r = new Random();
                    int x = r.Next(310, 435);
                    int y = r.Next(165, 215);
                    animazioneCamion(isc, x, y, isT);
                    Thread.Sleep(4000);
                }
                if (camion.materialeTrasportato == "organico") ///se il camion trasporta materiale organico , sarà trasportato nel impianto di compostaggio
                {
                    Application.Current.Dispatcher.Invoke(() => impiantoS.Text = string.Format("Camion {0} con  ( {1} ) inviato \nall'impianto di compostaggio e trituratrice", counter - 1, camion.materialeTrasportato));
                    Random r = new Random();
                    int x = r.Next(310, 435);
                    int y = r.Next(165, 215);
                    animazioneCamion(isc, x, y, isT);
                    Thread.Sleep(4000);
                }
            }
           
        }

        private void ElaboraCamionOrganico(Camion camion, Deposito compostaggio)
        {
            if (impiantoCompostaggio.AggiungiMateriale(camion.volume, camion.massa))
            {
                Application.Current.Dispatcher.Invoke(() => compost.Text = string.Format("Camion {0} elaborato in impianto di compostaggio", counter - 1));
                
                Thread.Sleep(4000);

                if (camion.materialeTrasportato == "organico non triturato")
                {
                    Application.Current.Dispatcher.Invoke(() => compost.Text = string.Format("Camion {0}: prodotto compost", counter - 1, camion.materialeTrasportato));
                    Random r = new Random();
                    int x = r.Next(565, 700);
                    int y = r.Next(165, 215);
                    animazioneCamion(icc, x, y, imcT);
                    Thread.Sleep(4000);
                }
                
            }
         
        }

        private void ElaboraCamionSelezionato(Camion camion, Deposito discarica)
        {
          
            if (discarica.AggiungiMateriale(camion.volume, camion.massa))
            {
                
                Application.Current.Dispatcher.Invoke(() => disc.Text = string.Format("Camion {0} inviato in discarica", counter - 1, camion.materialeTrasportato));
                Random r = new Random();
                int x = r.Next(65, 195);
                int y = r.Next(165, 215);
                
                animazioneCamion(dsc, x, y, disT);
                Thread.Sleep(4000);
            }
           
        }

        private async Task ElaborazioneCamionTask()
        {
            try
            {
                while (true)
                {
                    // Controlla se il timer è in pausa
                    while (!timer.IsEnabled)
                    {
                        await Task.Delay(1000);
                    }

                    if (codaCamion.Count > 0)
                    {
                        Camion camionCorrente;
                        lock (codaCamionLock)
                        {
                            camionCorrente = codaCamion.Dequeue();
                        }

                        Application.Current.Dispatcher.Invoke(() => ElaboraCamion(camionCorrente, discarica, impiantoSelezione, impiantoCompostaggio));
                        TrasportoCamion(camionCorrente);
                        await Task.Delay(2000);
                    }
                    else
                    {
                        await Task.Delay(1000);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore: " + ex.Message);
               
            }
        }

        private void AggiornaLabelDeposito(Deposito deposito, Label labelM, Label labelV)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                labelM.Content = $"{deposito.contenutoMassa:F2}";
                labelV.Content = $"{deposito.contenutoVolume:F2}";
                // Se sia la massa che il volume sono minori di 40, il testo sarà verde
                if (deposito.contenutoMassa < 40 && deposito.contenutoVolume < 40)
                {
                    labelM.Foreground = Brushes.Green;
                    labelV.Foreground = Brushes.Green;
                }
                // Se sia la massa che il volume sono compresi tra 40 e 75, il testo sarà arancione
                else if ((deposito.contenutoMassa >= 40 && deposito.contenutoMassa <= 75) || (deposito.contenutoVolume >= 40 && deposito.contenutoVolume <= 75))
                {
                    labelM.Foreground = Brushes.Orange;
                    labelV.Foreground = Brushes.Orange;
                }
                // Se sia la massa che il volume sono maggiori di 75, il testo sarà rosso
                else
                {
                    labelM.Foreground = Brushes.Red;
                    labelV.Foreground = Brushes.Red;
                }

                // Controllo della capienza massima
                if (deposito.contenutoMassa >= 95 || deposito.contenutoVolume >= 95)
                {

                    
                    // Rimuovi il deposito dalla visualizzazione grafica
                    if (deposito == discarica)
                    {
                        discarica.isDepositoFull = true;// discarica piena
                        dsc.Visibility = Visibility.Hidden; // nasconde i camion e il numero del camion
                        disT.Visibility = Visibility.Hidden;
                        disc.Visibility = Visibility.Hidden; //scompare il blocco discarica
                        full.Visibility = Visibility.Visible; //compare il messaggio PIENO!
                        discaricaLabelM.Visibility = Visibility.Hidden; //scompaiono i label con i dati
                        discaricaLabelV.Visibility = Visibility.Hidden;
                        mv1.Visibility = Visibility.Hidden;


                    }
                    else if (deposito == impiantoSelezione)
                    {
                        impiantoSelezione.isDepositoFull = true;
                        isc.Visibility = Visibility.Hidden; // nasconde i camion e il numero del camion
                        isT.Visibility = Visibility.Hidden;
                        impiantoS.Visibility = Visibility.Hidden; // Nascondi l'impianto di selezione
                        full1.Visibility = Visibility.Visible;
                        impLabelM.Visibility = Visibility.Hidden;
                        impLabelV.Visibility = Visibility.Hidden;
                        mv2.Visibility = Visibility.Hidden;

                    }
                    else if (deposito == impiantoCompostaggio)
                    {
                        impiantoCompostaggio.isDepositoFull = true;
                        icc.Visibility = Visibility.Hidden; // nasconde i camion e il numero del camion
                        imcT.Visibility = Visibility.Hidden;
                        compost.Visibility = Visibility.Hidden; // Nascondi l'impianto di compostaggio
                        full2.Visibility = Visibility.Visible;
                        compLabelM.Visibility = Visibility.Hidden;
                        compLabelV.Visibility = Visibility.Hidden;
                        mv3.Visibility = Visibility.Hidden;
                    }

                   

                }
                if(full.Visibility == Visibility && full1.Visibility== Visibility && full2.Visibility == Visibility)
                {
                    //se tutti e tre i depositi sono pieni, allora : 
                    camionInfoText.Visibility = Visibility.Hidden;
                    labAcc.Visibility = Visibility.Visible;
                    // interrompe l arrivo di nuovi camion
                    timerGeneraCamion.Stop();
                    timer.Stop();
                    MessageBox.Show("L'impianto complessivo ha chiuso per avere raggiunto la massima capienza"); 
                    //il programma si chiude
                    Environment.Exit(0);
                }
            });
        }
        private void animazioneCamion(Rectangle generico, int x, int y, TextBlock t)
        {
            // Imposta la posizione del rettangolo del camion e del textblock
            Canvas.SetLeft(generico, x);
            Canvas.SetTop(generico, y);
            Canvas.SetLeft(t, x);
            Canvas.SetTop(t, y);

            // Imposta la visibilità del rettangolo del camion e del textblock su Visible
            generico.Visibility = Visibility.Visible;
            t.Visibility = Visibility.Visible;

            // Imposta il testo del textblock
            t.Text = "00" + (counter - 1).ToString();
        }

        private Camion GeneraCamionRandom()
        {
            Random random = new Random();
            string[] materialiIndifferenziati = { "organico", "preselezionato" , "vetro", "plastica", "metallo", "organico non triturato" };
            string materiale = materialiIndifferenziati[random.Next(materialiIndifferenziati.Length)];

            double volume = Math.Round(random.NextDouble() * 20, 2); // Arrotonda il volume a due cifre decimali
            double massa = Math.Round(random.NextDouble() * 20, 2); // Arrotonda la massa a due cifre decimali

            return new Camion(materiale, volume, massa);
        }
        

        private async Task ElaboraCamion(Camion camion, Deposito discarica, Deposito impiantoSelezione, Deposito impiantoCompostaggio)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
               
                camionInfoText.Text = string.Format("In arrivo camion {3} trasportante: {0} - Volume: {1} - Massa: {2}", camion.materialeTrasportato, camion.volume, camion.massa, counter - 1);
                //discaricaN.Visibility= Visibility.Visible;
                
            });

            await Task.Delay(2000); // Introduce un ritardo di 2 secondi

            switch (camion.materialeTrasportato)
            {
                case "vetro":
                case "plastica":
                case "metallo":
                case "organico":
                   ElaboraCamionIndifferenziata(camion, impiantoSelezione);
                    break;
                case "organico non triturato":
                    ElaboraCamionOrganico(camion, impiantoCompostaggio);
                    break;
                case "preselezionato":
                    ElaboraCamionSelezionato(camion, discarica);
                    break;
                default:
                    break;
            }

            await Task.Delay(2000); // Introduce un ritardo casuale
        }

       
        private void TrasportoCamion(Camion camion)
        {
            switch (camion.materialeTrasportato)
            {
                case "vetro":
                case "plastica":
                case "metallo":
                case "organico":
                    Application.Current.Dispatcher.Invoke(() => impiantoS.Text = string.Format("Camion {0} elaborato in Impianto di Selezione", counter - 1));
                    break;
                case "organico non triturato":
                    Application.Current.Dispatcher.Invoke(() => compost.Text = string.Format("Camion {0} elaborato in Impianto di Compostaggio", counter - 1));
                    break;
                case "preselezionato":
                    Application.Current.Dispatcher.Invoke(() => disc.Text = string.Format("Camion {0} elaborato in Discarica", counter - 1));
                    break;
                default:
                    break;
            }
        }
    }
}

