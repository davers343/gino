﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace impianto
{
    class Camion
    {
        public string materialeTrasportato { get; set; }
        public double volume { get; set; }
        public double massa { get; set; }

        public Camion(string materiale, double volume, double massa)
        {
            materialeTrasportato = materiale;
            this.volume = volume;
            this.massa = massa;
        }
    }

}
