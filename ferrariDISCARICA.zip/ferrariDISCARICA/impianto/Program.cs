﻿using impianto;
using System;
using System.Collections.Generic;
using System.Threading;

namespace impianto
{
    class Program
    {
        static void Main1(string[] args)
        {

            const double CompressioneTempo = 1.0;
            Deposito discarica = new Deposito("Discarica", 1000 * CompressioneTempo, 0, 500 * CompressioneTempo, 0);
            Deposito impiantoSelezione = new Deposito("Impianto di selezionamento", 1000 * CompressioneTempo, 0, 500 * CompressioneTempo, 0);
            Deposito compostaggio = new Deposito("Impianto di selezionamento", 1000 * CompressioneTempo, 0, 500 * CompressioneTempo, 0);

            Queue<Camion> codaCamion = new Queue<Camion>(); ///creazione della coda di camion

            Thread gestioneCodaThread = new Thread(() =>   ///thread per gestire le code di camion
            {
                Random random = new Random();

                while (true)
                {
                    Camion nuovoCamion = GeneraCamionRandom(); ///genera un nuovo camion casuale
                    lock (codaCamion)
                    {
                        codaCamion.Enqueue(nuovoCamion);  ///mette in coda il camion appena creato
                    }
                    Thread.Sleep(random.Next(8000));  /// attende un certo tempo  prima di generare un nuovo camion
                }
            });
            Thread elaborazioneCamionThread = new Thread(() =>  ///elaborazione della coda di camion
            {
                while (true)
                {
                    if (codaCamion.Count > 0)  ///controlla che non ci siano camion in attesa
                    {
                        Camion camionCorrente;

                        lock (codaCamion)
                        {
                            camionCorrente = codaCamion.Dequeue();   ///toglie il camion dalla coda , cioè sarà eseguito
                        }
                        ElaboraCamion(camionCorrente, discarica, impiantoSelezione, compostaggio);
                        Thread.Sleep(new Random().Next(4000));
                    }
                    else
                    {
                        Thread.Sleep(4000); ///attesa di un tempo quando la coda è vuota
                    }
                }
            });
            gestioneCodaThread.Start();  /// avvio dei due thread per i camion
            elaborazioneCamionThread.Start();

        }

        static Camion GeneraCamionRandom()  ///metodo per generare i camion in modo casuale
        {
            Random random = new Random();
            string[] materialiIndifferenziati = { "organico", "preselezionato", "plastica", "vetro", "metallo", "organico non triturato" };  ///lista materiali disponibili

            string materiale = materialiIndifferenziati[random.Next(materialiIndifferenziati.Length)];   ///calcolo di un materiale random
            double volume = random.NextDouble() * 10;
            double massa = random.NextDouble() * 50;

            return new Camion(materiale, volume, massa);  ///restituisce un oggetto camion con le caratteristiche precedentemente generate
        }

        static void ElaboraCamion(Camion camion, Deposito discarica, Deposito impiantoSelezione, Deposito compostaggio)  ///metodo per elaborare i camion in arrivo ai depositi
        {
            Console.WriteLine("In arrivo camion trasportante: {0} - Volume: {1} - Massa: {2}", camion.materialeTrasportato, camion.volume, camion.massa);
            Thread.Sleep(2000);
            ///viene eseguito un controllo per capire quale materiale sta trasportando il camion corrente
            if (camion.materialeTrasportato == "preselezionato") ///se il camion trasporta materiale indifferenziato , sarà trasportato direttamente in discarica
            {
                if (discarica.AggiungiMateriale(camion.volume, camion.massa))
                {
                    Console.WriteLine("Camion con materiale preselezionato inviato in discarica");
                    Thread.Sleep(4000);
                }
                else
                {
                    Console.WriteLine("Allarme!!!: la discarica ha raggiunto la massima capienza, camion preselezionato non accettato");
                    Environment.Exit(0); //se è piena la discarica, il programma si spegne
                }
            }
            if (camion.materialeTrasportato == "plastica" || camion.materialeTrasportato == "metallo" || camion.materialeTrasportato == "vetro" || camion.materialeTrasportato == "organico") ///se il camion trasporta materiale indifferenziato , sarà trasportato nel deposito di selezione
            {
                if (impiantoSelezione.AggiungiMateriale(camion.volume, camion.massa))///se il camion trasporta un materiale differente , sarà trasportato nel deposito di selezione
                {
                    Console.WriteLine("Camion con materiale indifferenziato ( {0} ) inviato all'impianto di selezionamento", camion.materialeTrasportato);
                    Thread.Sleep(1000);

                    if (camion.materialeTrasportato == "plastica" || camion.materialeTrasportato == "metallo" || camion.materialeTrasportato == "vetro")
                    {
                        Console.WriteLine("Camion con  ( {0} ) in transito , in attesa di essere prelevato", camion.materialeTrasportato);
                        Thread.Sleep(4000);

                    }
                    if (camion.materialeTrasportato == "organico") ///se il camion trasporta materiale organico , sarà trasportato nel impianto di compostaggio
                    {
                        Console.WriteLine("Camion con  ( {0} ) inviato all'impianto di compostaggio e trituratrice", camion.materialeTrasportato);
                        Thread.Sleep(4000);
                    }

                }
                else
                {
                    Console.WriteLine("Allarme!!!: \tl'impianto di selezionamento ha raggiunto la massima capienza, camion non accettato");
                    Environment.Exit(0);
                }
            }
            if (camion.materialeTrasportato == "organico non triturato") ///se il camion trasporta materiale indifferenziato , sarà trasportato direttamente in discarica
            {
                if (compostaggio.AggiungiMateriale(camion.volume, camion.massa))
                {
                    Console.WriteLine("Camion con materiale organico non triturato inviato all'impianto di compostaggio");
                    Thread.Sleep(1000);
                    Console.WriteLine("Il materiale è stato triturato e prodotto compost");
                    Thread.Sleep(4000);
                }
                else
                {
                    Console.WriteLine("Allarme!!!: l'impianto di compostaggio ha raggiunto la massima capienza, camion preselezionato non accettato");
                    Environment.Exit(0); //se è piena la discarica, il programma si spegne
                }
            }
        }
    }
}


