﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace impianto
{
    class Deposito
    {
        ///la classe deposito permette di generare un nuovo deposito date le sue proprietà
        private readonly object bloccaOggetto = new object();  ///readonly comporta che bloccaOggetto non possa mai cambiare nel corso dell'esecuzione
        public string nome { get; }
        public double capienzaVolume { get; }
        public double contenutoVolume { get; private set; }
        public double capienzaMassa { get; }
        public double contenutoMassa { get; private set; }
        public bool isDepositoFull = false;
        public Deposito(string nome, double capienzaVolume, double contenutoVolume, double capienzaMassa, double contenutoMassa)
        {
            this.nome = nome;
            this.capienzaVolume = capienzaVolume;
            this.contenutoVolume = contenutoVolume;
            this.capienzaMassa = capienzaMassa;
            this.contenutoMassa = contenutoMassa;
        }

        public bool AggiungiMateriale(double volume, double massa) ///metodo per riempire i depositi, accetterà nuovi materiali da camion diversi finchè non avrà raggiunto la massima capienza( 
        {
            lock (bloccaOggetto)  ///lock permette di sincronizzare i thread e limitare l'accesso alla sezione critica, in questo caso la seguente, ad  un solo thread per volta( cioè un solo camion per volta può accedere ai vari depositi)
            {
                if (contenutoVolume + volume <= capienzaVolume && contenutoMassa + massa <= capienzaMassa)
                {
                    contenutoVolume += volume;
                    contenutoMassa += massa;

                    double percentualeVolume = (contenutoVolume / capienzaVolume) * 100;
                    double percentualeMassa = (contenutoMassa / capienzaMassa) * 100;

                    if (percentualeVolume > 95 || percentualeMassa > 95)
                    {
                        Console.WriteLine("Allarme: {0} ha raggiunto la massima capienza! \t La percentuale di riempimento superiore al 95%\tNon saranno accettati nuovi camion!", nome);
                    }

                    return true;
                }

                return false;
            }
        }
    }
}


